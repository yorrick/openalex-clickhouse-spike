#!/bin/bash
set -euo pipefail
cd /opt/oa200
while ! test -f results/engines-complete.json; do
 if test -f results/engine-error.json; then echo 'Baseline failed; inspect evidence before repair'; exit 1; fi
 # Leave more than 90 minutes before the independent termination deadline.
 if test "$(date -u +%s)" -gt 1794547200; then echo 'Repair time reserve exhausted'; exit 1; fi
 sleep 5
done
exec .venv/bin/python repair_pg_shm.py
