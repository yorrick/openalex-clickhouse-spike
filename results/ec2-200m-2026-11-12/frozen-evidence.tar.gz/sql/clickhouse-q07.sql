SELECT citing_year, cited_work_id, count(*) AS citations
            FROM citation_edge GROUP BY citing_year, cited_work_id
            ORDER BY citations DESC, cited_work_id, citing_year NULLS LAST LIMIT 1000;
