#!/bin/bash
set -euo pipefail
cd /opt/oa200
while ! test -f results/postgres/repair-complete.json; do
 if systemctl is-failed --quiet oa200-pg-repair.service; then echo 'PG repair failed; inspect before CH trial'; exit 1; fi
 if test "$(date -u +%s)" -gt 1794547200; then echo 'CH trial time reserve exhausted'; exit 1; fi
 sleep 5
done
exec .venv/bin/python trial_ch_grace.py
